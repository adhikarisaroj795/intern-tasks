const li_search = document.getElementById("nav-bar-search");
const searchInput = document.getElementById("search-input");

li_search.addEventListener("click", (event) => {
  event.preventDefault();
  searchInput.classList.toggle("visible");
});
